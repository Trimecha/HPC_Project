#ifndef VIEWER_HPP
#define VIEWER_HPP

/**@file
 * @brief Define the viewer.
 *
 * This file defines the Viewer class that manages the display window,
 * the renderables, the user input and the shader programs.
 */

#include "Renderable.hpp"
#include "Camera.hpp"
#include "lighting/Light.hpp"
#include "TextEngine.hpp"
#include "FPSCounter.hpp"
#include "dynamics/DynamicSystem.hpp"

#include <unordered_set>
#include <memory>
#include <string>
#include <chrono>

#include <GL/glew.h>
#include <SFML/Graphics.hpp>
#include <SFML/OpenGL.hpp>
#include <glm/gtc/type_precision.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <mpi.h>
#include <boost/mpi.hpp>
namespace mpi = boost::mpi;

class Viewer
{

private:
    friend class boost::serialization::access;

    template<class Archive>
    void serialize(Archive & ar, const unsigned int version)
    {
      sf::RenderWindow* m_window; /*!< Pointer to the render window. */
      std::unordered_set< RenderablePtr > m_renderables; /*!< Set of renderables that the viewer displays. */
      DirectionalLightPtr m_directionalLight; /*!< Pointer to a directional light. */
      std::vector<PointLightPtr> m_pointLights; /*!< Vector of pointer to the point lights. */
      std::vector<SpotLightPtr> m_spotLights; /*!< Vector of pointer to the spot lights. */
      std::unordered_set< ShaderProgramPtr > m_programs;

      TextEngine m_tengine; /*!< Engine to display textual information. */
      TimePoint m_modeInformationTextDisappearanceTime; /*!< Duration of appearance for textual information in seconds. */
      std::string m_modeInformationText; /*!< Textual information that will be displayed. */

      bool m_applicationRunning; /*!< Boolean that runs the main animation loop. Always true except when closing the application. */
      bool m_animationLoop; /*!< True if the animation loops after a given duration, \ref m_loopDuration. */
      bool m_animationIsStarted; /*!< True if the animation is running. False otherwise. */
      float m_loopDuration; /*!< Duration of the animation loop in seconds. */
      float m_simulationTime; /*!< Current simulation time in the animation loop. */
      TimePoint m_lastSimulationTimePoint; /*!< Date of the last simulation. */

      glm::vec3 m_currentMousePosition; /*!< Current mouse cursor coordinates normalized between [-1,1]. The z-value is set to 1. */
      glm::vec3 m_lastMousePosition; /*!< Previous mouse cursor coordinates normalized between [-1,1]. The z-value is set to 1. */

      unsigned int m_screenshotCounter; /*!< Number of screenshots since the beginning of the application. */

      FPSCounter m_fpsCounter; /*!< A framerate counter */
      bool m_helpDisplayed;

      Camera m_camera; /*!< Camera used to render the scene in the Viewer. */
      DynamicSystem* m_system;
    }

public:

    typedef std::chrono::system_clock clock;
    typedef std::chrono::duration<double> Duration;
    typedef std::chrono::time_point< clock, Duration > TimePoint;

    ~Viewer();
    Viewer() {};
    Viewer(float width, float height, mpi::communicator world);
    void initViewer(float width, float height, mpi::communicator world);

    void setSystem(DynamicSystem* s) {m_system = s;};
    DynamicSystem* getSystem() {return m_system;};
    void addShaderProgram( ShaderProgramPtr program );
    void reloadShaderPrograms();

    bool isRunning() const;
    void display();
    void draw();
    void animate();
    void handleEvent();

    void changeCameraMode();
    Camera& getCamera();
    glm::vec3 windowToWorld( const glm::vec3& windowCoordinate );
    glm::vec3 worldToWindow( const glm::vec3& worldCoordinate );
    void addRenderable( RenderablePtr r );
    void takeScreenshot();
    float getTime();
    void startAnimation();
    void stopAnimation();
    void resetAnimation();
    void setAnimationLoop(bool animationLoop, float loopDuration=0.0);
    void setDirectionalLight(const DirectionalLightPtr& directionalLight);
    void addPointLight(const PointLightPtr& pointLight);
    void addSpotLight(const SpotLightPtr& spotLight);
    void displayText(std::string text, Viewer::Duration duration = std::chrono::seconds(3));

    bool getMirror() {return mirror;};
    bool getCollision() {return collision;};
private:
    void keyPressedEvent(sf::Event& e);
    void keyReleasedEvent(sf::Event& e);
    void mousePressEvent(sf::Event& e);
    void mouseReleaseEvent(sf::Event& e);
    void mouseWheelEvent(sf::Event& e);
    void mouseMoveEvent(sf::Event& e);


    sf::RenderWindow* m_window; /*!< Pointer to the render window. */
    std::unordered_set< RenderablePtr > m_renderables; /*!< Set of renderables that the viewer displays. */
    DirectionalLightPtr m_directionalLight; /*!< Pointer to a directional light. */
    std::vector<PointLightPtr> m_pointLights; /*!< Vector of pointer to the point lights. */
    std::vector<SpotLightPtr> m_spotLights; /*!< Vector of pointer to the spot lights. */
    std::unordered_set< ShaderProgramPtr > m_programs;

    TextEngine m_tengine; /*!< Engine to display textual information. */
    TimePoint m_modeInformationTextDisappearanceTime; /*!< Duration of appearance for textual information in seconds. */
    std::string m_modeInformationText; /*!< Textual information that will be displayed. */

    bool m_applicationRunning; /*!< Boolean that runs the main animation loop. Always true except when closing the application. */
    bool m_animationLoop; /*!< True if the animation loops after a given duration, \ref m_loopDuration. */
    bool m_animationIsStarted; /*!< True if the animation is running. False otherwise. */
    float m_loopDuration; /*!< Duration of the animation loop in seconds. */
    float m_simulationTime; /*!< Current simulation time in the animation loop. */
    TimePoint m_lastSimulationTimePoint; /*!< Date of the last simulation. */

    glm::vec3 m_currentMousePosition; /*!< Current mouse cursor coordinates normalized between [-1,1]. The z-value is set to 1. */
    glm::vec3 m_lastMousePosition; /*!< Previous mouse cursor coordinates normalized between [-1,1]. The z-value is set to 1. */

    unsigned int m_screenshotCounter; /*!< Number of screenshots since the beginning of the application. */

    bool mirror=true;
    bool collision = true;
    FPSCounter m_fpsCounter; /*!< A framerate counter */
    bool m_helpDisplayed;

    Camera m_camera; /*!< Camera used to render the scene in the Viewer. */
    DynamicSystem* m_system;

    mpi::communicator m_world;

    struct KeyboardState {
      bool forward;
      bool backward;
      bool left;
      bool right;
      bool slow;
      bool fast;

      glm::vec3 direction;
      float speed;

      KeyboardState();
    };

    KeyboardState keyboard; /*!< Help us to smoothly control the camera with the keyboard. */
    TimePoint m_lastEventHandleTime; /*!< Last time all input events were handled.*/
};

#endif
