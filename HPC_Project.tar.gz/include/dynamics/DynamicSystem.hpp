#ifndef DYNAMICSYSTEM_HPP
#define DYNAMICSYSTEM_HPP

#include <vector>

#include "../Plane.hpp"
#include "../KdTree.hpp"
#include "Collision.hpp"
#include "Particle.hpp"
#include "ParticleSphereCollision.hpp"
#include "ParticleParticleCollision.hpp"
#include <boost/mpi.hpp>
namespace mpi = boost::mpi;

/**@brief A dynamic system.
 *
 * This class represents a dynamic system made of particles, force fields and
 * fixed planes obstacles and that handle collisions. If you want to, you can
 * replace fixed planes obstacles by triangle obstacles: you will be able to
 * model more kind of obstacles. However, this would require a spatial optimization
 * that is out of the scope of these practical lessons.
 */
class DynamicSystem
{
private:
    friend class boost::serialization::access;

    template<class Archive>
    void serialize(Archive & ar, const unsigned int version)
    {
        ar & m_planeObstacles;
        ar & m_dt;
        ar & m_collisions;
        ar & m_handleCollisions;
        ar & m_mirror;
        ar & m_boidsIntteraction;
        ar & m_restitution;
        ar & m_sphereObstacle;
        ar & m_field_size;
        ar & m_boids;
        ar & m_boidsTree;
        ar & m_process;
        ar & m_influence_range;
    }
  public:

    std::vector<Plane*> m_planeObstacles;
    float m_dt;
    std::vector<Collision*> m_collisions;
    bool m_handleCollisions;
    bool m_mirror;
    bool m_boidsIntteraction;
    float m_restitution;
    Sphere* m_sphereObstacle;
    float m_field_size;

    KdTree* m_boidsTree;
    std::vector<Particle*> m_boids;
    int m_process;
    double m_influence_range;

public:
    mpi::communicator m_world;
    ~DynamicSystem();
    DynamicSystem(float field_size, mpi::communicator world);
    DynamicSystem() {};

    void updateBoidsFromTree();
    Sphere* getSphereObstacle() { return m_sphereObstacle; };
    void setSphereObstacle(Sphere* s) { m_sphereObstacle = s; };
    void addParticle(Particle* p);
    void addPlaneObstacle(Plane* planeObstacle);
    bool getMirror() { return m_mirror; };
    void setMirror(bool b) { m_mirror = b; };
    bool getCollisionDetection();
    void setCollisionsDetection(bool onOff);
    void createBoidSwarm(vector<Particle*>& particles);
    bool getBoidsInteraction();
    void setBoidsInteraction(bool onOff);
    std::vector<Particle*>& getParticles();
    void setParticles(const std::vector<Particle*> & particles);
    void computeSimulationStep();
    const float getRestitution();
    void setRestitution(const float &restitution);
    float getDt() const;
    void setDt(float dt);
    void revertCollision() {m_handleCollisions = !m_handleCollisions;};
    void revertMirror() {m_mirror = !m_mirror;};
    KdTree* boidsTree() {return m_boidsTree;};
    vector<Particle*> boids() {return m_boids;};
    void clearBoids() {m_boids.clear();};
    static void fusion(vector<DynamicSystem> sys, mpi::communicator world, DynamicSystem* res);
    void clear();

private:
    void detectCollisions();
    void handleBoidsInteraction(float dt);
    void solveCollisions();
    void handleMirrorEffect();

};

typedef std::shared_ptr<DynamicSystem> DynamicSystemPtr;

/**
 * \brief output stream operator, as non-member
 */
std::ostream& operator<<(std::ostream& os, const DynamicSystemPtr& system);


#endif
