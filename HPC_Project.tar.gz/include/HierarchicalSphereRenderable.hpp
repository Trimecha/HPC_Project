#ifndef HIERARCHICAL_SPHERE_RENDERABLE_HPP
#define HIERARCHICAL_SPHERE_RENDERABLE_HPP

#include "HierarchicalRenderable.hpp"
#include "Sphere.hpp"
#include "Viewer.hpp"
#include <vector>
#include <glm/glm.hpp>


class HierarchicalSphereRenderable : public HierarchicalRenderable
{
    struct facet {
      glm::vec3 a;
      glm::vec3 b;
      glm::vec3 c;
    };
    typedef struct facet facet;

    public:
        virtual void whoAmI() { std::cout << "HierarchicalSphereRenderable\n"; };

        ~HierarchicalSphereRenderable();
        HierarchicalSphereRenderable( ShaderProgramPtr program, Sphere* sphere, Viewer* viewer);

    private:
        void sortFacets();
        void sortPositions();

        void do_draw();
        void do_animate( float time );

        Viewer* m_viewer;

        std::vector< glm::vec3 > m_positions;
        std::vector< glm::vec4 > m_colors;
        std::vector< glm::vec3 > m_normals;

        std::vector< facet > m_facets;

        Sphere* m_sphere;
        static glm::vec3 m_lastCameraPos;

        glm::mat4 m_model;

        unsigned int m_pBuffer;
        unsigned int m_cBuffer;
        unsigned int m_nBuffer;
};

typedef std::shared_ptr<HierarchicalSphereRenderable> HierarchicalSphereRenderablePtr;

#endif //HIERARCHICAL_SPHERE_RENDERABLE_HPP
