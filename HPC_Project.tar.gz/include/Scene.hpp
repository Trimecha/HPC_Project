#ifndef SCENE_HPP
#define SCENE_HPP

#include <stdbool.h>

#include "Viewer.hpp"
#include "ShaderProgram.hpp"
#include "FrameRenderable.hpp"
#include "HierarchicalCubeRenderable.hpp"
#include "HierarchicalSphereRenderable.hpp"
#include "Utils.hpp"

#include "lighting/LightedParticleRenderable.hpp"
#include "lighting/Material.hpp"
#include "lighting/Light.hpp"

#include "dynamics/DynamicSystem.hpp"
#include "dynamics/DynamicSystemRenderable.hpp"
#include <boost/mpi.hpp>
namespace mpi = boost::mpi;

class Scene {
	public:
  		Scene(Viewer* viewer, mpi::communicator world,  int nbBoids);
  		~Scene();

      void initialize_scene();
			static glm::vec3 get_random_vec3(double lower_bound, double upper_bound);

			DynamicSystem* getSystem() {return m_system;};
			vector<Particle*> getboids() {return m_boids;};
  private:
			void light();
			void boids();
			void cube_hitmap();
			void sphere_hitmap();

			vector<Particle*> m_boids;
			float m_hitmap_width;
			int  m_num_boids;
			float m_rboid;
      Viewer *m_viewer;
      ShaderProgramPtr m_flatShader;
			ShaderProgramPtr m_phongShader;
      DynamicSystem* m_system;
      DynamicSystemRenderablePtr m_systemRenderable;
};

#endif // SCENE_H
