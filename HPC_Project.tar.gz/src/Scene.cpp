#include "../include/Scene.hpp"


Scene::Scene(Viewer* viewer, mpi::communicator world, int nbBoids) {
    m_hitmap_width = 1.0;
    m_rboid = 0.01;
    m_num_boids = nbBoids;

    m_viewer = viewer;
    m_flatShader = std::make_shared<ShaderProgram>("./../shaders/flatVertex.glsl", "./../shaders/flatFragment.glsl");
    // Define a shader that encode an illumination model
    m_phongShader = std::make_shared<ShaderProgram>("../shaders/phongVertex.glsl", "../shaders/phongFragment.glsl");
    // Initialize a dynamic system (Solver, Time step, Restitution coefficient)
    m_system = new DynamicSystem(m_hitmap_width,world);
	  // Create a renderable associated to the dynamic system
    m_systemRenderable = std::make_shared<DynamicSystemRenderable>(m_system,world,m_viewer);
}

Scene::~Scene() {}

void Scene::initialize_scene()
{
    m_viewer->getCamera().setViewMatrix( glm::lookAt( glm::vec3( -0.1, 0, 2 ), glm::vec3(0,0,0), glm::vec3(0,0,-1)));
    m_viewer->addShaderProgram(m_phongShader);
    m_viewer->addShaderProgram(m_flatShader);
    m_viewer->setSystem(m_system);

    m_system->setDt(0.005);
    m_system->setCollisionsDetection(true); // Activate collision detection
    m_system->setMirror(false);
    m_system->setRestitution(1.0f); // Restitution coefficient for collision - 1.0 = full elastic response, 0.0 = full absorption
    m_viewer->addRenderable(m_systemRenderable);

    light();
    boids();
    cube_hitmap();
    //sphere_hitmap();

    m_viewer->startAnimation();
}

void Scene::light()
{
    glm::vec3 d_direction = glm::normalize(glm::vec3(0.0,-1.0,-1.0));
    glm::vec3 d_ambient(1.0,1.0,1.0), d_diffuse(0.3,0.3,0.1), d_specular(1.0,1.0,1.0);
    DirectionalLightPtr directionalLight = std::make_shared<DirectionalLight>(d_direction, d_ambient, d_diffuse, d_specular);
    m_viewer->setDirectionalLight(directionalLight);
}

void Scene::boids()
{
    float epsilon = 2*m_rboid;
    glm::vec3 px,pv;
    float pm, pr;
    Particle* p;
    MaterialPtr materials[3] = {Material::Emerald(),Material::Pearl(),Material::Bronze() };
    float openGLFactor=128.0;
    glm::vec3 ambient(0.8,0.0,0.0);
    glm::vec3 diffuse(0.0,0.0,0.0);
    glm::vec3 specular(1.0,1.0,1.0);
    float shininess = openGLFactor*0.01;
    MaterialPtr boidsMaterial =  std::make_shared<Material>(ambient, diffuse, specular, shininess);

    vector<Particle*> particles;
    LightedParticleRenderablePtr pRenderable;
    for (int i=0; i<m_num_boids; i++)
    {
        //Initialize a particle with position, velocity, mass and radius and add it to the system
        px = get_random_vec3(-m_hitmap_width/4,m_hitmap_width/4);
        glm::vec3 offset(m_hitmap_width/8);
        float r = random(0,m_hitmap_width/4);
        float phi = random(0,2*M_PI);
        float theta = random(0,2*M_PI);
        px.x = r * sin(phi) * cos(theta);
        px.y = r * sin(phi) * sin(theta);
        px.z = r * cos(phi);
        px += offset;
        pv = get_random_vec3(-epsilon,epsilon);
        pr = m_rboid;
        pm = 0.01;

        p = new Particle(px, pv, pm, pr,0,m_num_boids);
        //if (i< 10)  p->setFixed(true);
        particles.push_back(p);
        m_boids.push_back(p);

        pRenderable = std::make_shared<LightedParticleRenderable>(m_phongShader, p, m_viewer, i);
        pRenderable->setMaterial(boidsMaterial);
        HierarchicalRenderable::addChild( m_systemRenderable, pRenderable );
    }
    m_system->createBoidSwarm(particles);

}

void Scene::sphere_hitmap() {
    float r = m_hitmap_width/2;
    glm::vec3 origin(0,0,0);
    Sphere* s = new Sphere(origin,r);
    m_system->setSphereObstacle(s);

    HierarchicalSphereRenderablePtr sRenderable = std::make_shared<HierarchicalSphereRenderable>(m_flatShader,s,m_viewer);
    HierarchicalRenderable::addChild( m_systemRenderable, sRenderable );
}
void Scene::cube_hitmap() {
    glm::vec3 p1, p2, p3, p4;
    float e = m_hitmap_width/2;

    p1 = glm::vec3(-e,-e,-e);
    p2 = glm::vec3(e,-e,-e);
    p3 = glm::vec3(e,e,-e);
    p4 = glm::vec3(-e,e,-e);
    Plane* plane = new Plane(p1, p2, p3);
    m_system->addPlaneObstacle(plane);
    p1 = glm::vec3(e,-e,e);
    p2 = glm::vec3(-e,-e,e);
    p3 = glm::vec3(-e,e,e);
    p4 = glm::vec3(e,e,e);
    plane = new Plane(p1, p2, p3);
    m_system->addPlaneObstacle(plane);
    p1 = glm::vec3(-e,e,-e);
    p2 = glm::vec3(e,e,-e);
    p3 = glm::vec3(e,e,e);
    p4 = glm::vec3(-e,e,e);
    plane = new Plane(p1, p2, p3);
    m_system->addPlaneObstacle(plane);
    p1 = glm::vec3(-e,-e,-e);
    p2 = glm::vec3(-e,-e,e);
    p3 = glm::vec3(e,-e,e);
    p4 = glm::vec3(e,-e,-e);
    plane = new Plane(p1, p2, p3);
    m_system->addPlaneObstacle(plane);
    p1 = glm::vec3(-e,-e,-e);
    p2 = glm::vec3(-e,e,-e);
    p3 = glm::vec3(-e,e,e);
    p4 = glm::vec3(-e,-e,e);
    plane = new Plane(p1, p2, p3);
    m_system->addPlaneObstacle(plane);
    p1 = glm::vec3(e,-e,-e);
    p2 = glm::vec3(e,-e,e);
    p3 = glm::vec3(e,e,e);
    p4 = glm::vec3(e,e,-e);
    plane = new Plane(p1, p2, p3);
    m_system->addPlaneObstacle(plane);
    HierarchicalCubeRenderablePtr cubeRenderable = std::make_shared<HierarchicalCubeRenderable>(m_flatShader,e,m_viewer);
    //cubeRenderable->setLocalTransform(glm::scale(glm::mat4(1.0), glm::vec3(0.1,1.0,1.0)));
    HierarchicalRenderable::addChild( m_systemRenderable, cubeRenderable );
}

glm::vec3 Scene::get_random_vec3(double lower_bound, double upper_bound)
{
  glm::vec3 random_vec;
  random_vec.x = lower_bound + (rand() / ( RAND_MAX / (upper_bound-lower_bound) ) ) ;
  random_vec.y = lower_bound + (rand() / ( RAND_MAX / (upper_bound-lower_bound) ) ) ;
  random_vec.z = lower_bound + (rand() / ( RAND_MAX / (upper_bound-lower_bound) ) ) ;
  return random_vec;
}
