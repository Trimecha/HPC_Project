#include "../../include/dynamics/Particle.hpp"


Particle::Particle(glm::vec3 position, glm::vec3 velocity, float mass, float radius, float influence, int nbBoids)
    : m_initialPosition( position ), m_initialVelocity( velocity ),
      m_oldVelocity(velocity),
      m_position(position),
      m_velocity(velocity),
      m_acceleration(glm::vec3(0.0,0.0,0.0)),
      m_force(glm::vec3(0.0,0.0,0.0)),
      m_mass(mass),
      m_radius(radius), m_isFixed( false )
{

  m_influence_range = influence;
  minsep       = m_influence_range / 2;
  if (nbBoids <= 10) {
    max_force    = 0.01;
    max_speed    = 0.01;
  }
  if (nbBoids <= 30) {
    max_force    = 0.05;
    max_speed    = 0.05;
  }
  else if (nbBoids <= 300){
    max_force    = 0.1;
    max_speed    = 0.1;
  }
  else {
    max_force    = 0.5;
    max_speed    = 0.5;
  }
  cohesion_strength = 50;
  align_strength = 50;
  sep_strength = 1;
  m_neighbors = 0;
  sep_f = glm::vec3(0, 0, 0);
  cohesion_f = glm::vec3(0, 0, 0);
  align_f = glm::vec3(0, 0, 0);
  cohes_sum = glm::vec3(0, 0, 0);
}

Particle::~Particle()
{}

void Particle::restart()
{
  m_position = m_initialPosition;
  m_velocity = m_initialVelocity;
}

std::ostream& operator<<(std::ostream& os, const Particle* p)
{
    const glm::vec3& x = p->getPosition();
    const glm::vec3& v = p->getVelocity();

    os << "pos (" << x[0] << ", " << x[1] << ", " << x[2] << ")";
    os << " ; ";
    os << "vel (" << v[0] << ", " << v[1] << ", " << v[2] << ")";

    return os;
}

double Particle::get_speed()
{
  return glm::length(m_velocity);
}

void Particle::set_speed(double s)
{
  double random = -0.05 + (rand() / ( RAND_MAX / 0.1 ));
  if (glm::length(m_velocity) == 0)
      m_velocity = glm::vec3(random);
  m_velocity = glm::normalize(m_velocity);
  m_velocity *= s;
}

void Particle::limit(glm::vec3 vector, double lim)
{
   /*
   limit a vector to a given magnitude
   this is an 'in place' function, modifies the vector supplied.
   */
   if (glm::length(vector) > lim)
   {
       vector = glm::normalize(vector);
       vector *= lim;
   }
}

void Particle::update(double t)
{
    // Method to update position by computing displacement from velocity and acceleration
    glm::vec3 dv = m_acceleration;
    dv *= t;
    m_velocity += dv;
    limit(m_velocity, max_speed);
    glm::vec3 dp = m_velocity;
    dp *= t;
    m_position += dp;
}

void Particle::interact(std::vector<Particle*>& actors)
{
    // Unit-unit interaction method, combining a separation force, and velocity
    // alignment force, and a cohesion force.
    // Many examples separate these into different functions for clarity
    // but combining them means we need fewer loops over the neibor list
    sep_f = glm::vec3(0.0,0.0,0.0);;
    align_f = glm::vec3(0.0,0.0,0.0);;
    cohes_sum = glm::vec3(0.0,0.0,0.0);;

    glm::vec3 diff;
    int count = 0;
    double d;
    for(Particle* other : actors)
    {
        if (!compare_vec3(m_position,other->getPosition()))
        {
            m_neighbors = actors.size()-1;
            diff = m_position - other->m_position;
            d = glm::length(diff);
            if (0 < d && d < m_influence_range)
            {
              count += 1;
              diff = glm::normalize(diff);
              if (d < minsep)
                diff *= max_force;
              else
                diff /= d;  // Weight by distance

              sep_f += diff;
              cohes_sum += other->m_position;  // Add position
              align_f +=  other->m_velocity;
            }
        }
    }

    if (count > 0)
    {
      sep_f /= count;
      sep_f *= max_speed;
      limit(sep_f, max_force);
      // calc the average direction (normed avg velocity)
      align_f /= count;
      align_f *= max_speed;
      limit(align_f, max_force);
      // calc the average position and calc steering vector towards it
      cohes_sum /= count;
      cohesion_f = steer(cohes_sum, true);
      sep_f *= sep_strength;
      align_f *= align_strength;
      cohesion_f *= cohesion_strength;
      // finally add the velocities
      glm::vec3 sum = sep_f + cohesion_f + align_f;
      m_acceleration = sum;
    }
    //m_position.z = 0;
}

glm::vec3 Particle::steer(glm::vec3 desired, bool slowdown)
{

    //A helper method that calculates a steering vector towards a target
    //If slowdown is true the steering force is reduced as it approaches the target
    glm::vec3 st;
    double d = glm::length(desired);
    // If the distance is greater than 0, calc steering (otherwise return zero vector)
    if (d > 0)
    {
        desired = glm::normalize(desired);
        if (slowdown && (d < minsep))
            desired *= (max_speed*d / minsep);
        else
            desired *= max_speed;

        st = desired - m_velocity;
        limit(st, max_force);
    }
    else
        st = glm::vec3(0, 0, 0);
    return st;
}
